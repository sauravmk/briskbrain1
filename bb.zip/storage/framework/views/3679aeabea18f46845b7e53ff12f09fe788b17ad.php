       <footer class="footer">
            <div class="top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-lg-4">
                            <div class="recent-post">
                                <a class="navbar-brand" href="index.html"><img src="img/briskbraintech-flogo.png" class="img-logo" alt=""></a>
                                <div class="connect-outer">
                                    <h4>Contact Info</h4>
                                    <ul class="contact-sec">
                                        <li><a href="tel:+91 9428889935"><i class="fa fa-mobile-phone" aria-hidden="true"></i>+91 9428889935</a></li>
                                        <li><a href="mailto:hello@briskbraintech.com"><i class="fa fa-envelope mailicon" aria-hidden="true"></i>hello@briskbraintech.com</a></li>
                                        <li class="address-li">
                                            <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a>
                                            <p>1107, Ganesh Glory, Off S.G. Highway, Gota Ahmedabad, Gujarat 382481</p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-2">
                            <div class="quick-links">
                                <h4>Quick Links</h4>
                                <ul class="footertext">
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('home')); ?>">Home</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('about')); ?>">About Us</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('service')); ?>">Services</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('portfolio')); ?>">Portfolio</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('blog')); ?>">Read Our Blog</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('contact')); ?>">Contact Us</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="request-a-quote.html">Request a Quote</a></li>
                                </ul>
                            </div>
                        </div>                        
                        <div class="col-md-4 col-lg-3">
                            <div class="subscribe">
                                <h4>Our Expertise</h4>
                                <ul class="footertext">
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="yii-framework-development.html">Yii Framework Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="laravel-development.html">Laravel Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="codeigniter-development.html">CodeIgniter Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="custom-php-development.html">Custom PHP Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="magento-development.html">Magento E-Commerce Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="wordpress-development.html">WordPress Development</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="ruby-development.html">Ruby on Rails Development</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-3">
                            <div class="subscribe">
                                <h4>Recent Posts</h4>
                                <ul class="footertext">
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="javascript:void(0)">Top Laravel Best Practices In 2021</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="javascript:void(0)">How to Set up Vue, Vuex, Vue-Router & Sass in Laravel 8</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="javascript:void(0)">Building a CRUD system using Laravel 8, Laravel Orion, Angular 11 & JWT</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="javascript:void(0)">How to setup and configure Ejabberd on Ubuntu 16.04 EC2 AWS ?</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom">
                <div class="container">Copyright © Briskbrain Technologies - All rights reserved</div>
            </div>
        </footer>
        <a href="#" class="scroll-top"><i class="fa fa-angle-up" aria-hidden="true"></i></a> 
        <script type="text/javascript" src="js/jquery.min.js"></script> 
        <script type="text/javascript" src="js/popper.min.js"></script> 
        <script type="text/javascript" src="js/bootstrap.min.js"></script> 
        <script type="text/javascript" src="js/bxslider.min.js"></script> 
        <script type="text/javascript" src="js/owl.carousel.min.js"></script> 
        <script type="text/javascript" src="js/magnific-popup.min.js"></script> 
        <script type="text/javascript" src="js/counterup.min.js"></script> 
        <script type="text/javascript" src="js/waypoints.min.js"></script> 
        <script type="text/javascript" src="js/isotope.min.js"></script> 
        <script type="text/javascript" src="js/custom.js"></script>
        <script type="text/javascript" src="js/common.js"></script>
        <script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
    </body>
</html><?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/layouts/inc/frontend-footer.blade.php ENDPATH**/ ?>