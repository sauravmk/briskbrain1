<?php $__env->startSection('content'); ?>
        <section class="banner-section blog-banner">
            <div class="container">
                <div class="contents">
                    <h1>Blog</h1>
                    <p>Do you want to discuss your project with us? Well, give us a call, send us an email or fill out below form.</p>
                </div>
            </div>
        </section>
        <section class="blog-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-lg-9">
                        <div class="blog-content">
                            <ul class="blog-content-common">
                                <li>
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/laravel.png"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid" src="img/blog/laravel.png" alt=""></figure>
                                    </div>
                                    <p class="time">July 5, <span>2021</span></p>
                                    <h5>TOP LARAVEL BEST PRACTICES IN 2021</h5>
                                    <div class="box">
                                        <ul class="blog-info">
                                            <li class="comment"><a href="blog-single.html/#commentid">No comments yet</a></li>
                                            <li class="icon-men"><a href="home.html">By admin</a></li>
                                        </ul>
                                    </div>
                                    <p>Read here about the best practices for Laravel development. You can see the use of smartphones is increasing with every second of the time. It’s logical that if the use of smartphones increases, then the use of applications and websites is also going to increase. So, it is always beneficial to be updated with advanced development frameworks. Recently many new</p>
                                    <a href="blog-single.html" class="know-more">Read more</a> 
                                    <div class="social-media-box socialbox">
                                        <ul>
                                            <li><a target="_blank" href="https://www.facebook.com/BriskBrainTechnologies/"><i class="fa fa-facebook"></i></a></li>
                                            <li><a target="_blank" href="https://www.linkedin.com/company/briskbrain/"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a target="_blank" href="https://twitter.com/BriskBrain2"><i class="fa fa-twitter"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/email?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-envelope"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/whatsapp?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-whatsapp"></i></a></li>
                                        </ul>
                                    </div>
                                </li>
                                                                    
                                </li>
                                <li>
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/xampp.jpg"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid" src="img/blog/xampp.jpg" alt=""></figure>
                                    </div>
                                    <p class="time">February 19, <span>2021</span></p>
                                    <h5>How to setup and configure Ejabberd on Ubuntu 16.04 EC2 AWS ?</h5>
                                    <div class="box">
                                        <ul class="blog-info">
                                            <li class="comment"><a href="blog-single.html/#commentid">No comments yet</a></li>
                                            <li class="icon-men"><a href="home.html">By admin</a></li>
                                        </ul>
                                    </div>
                                    <p>1. Setup EC2 instance 2. Login to your EC2 instance with Terminal or Putty . 3. Install Ejabberd sudo apt-get -y install ejabberd Note- If you get any error like “package not found” then run sudo apt-get update and try the above command again. 4. Edit Config File to setup admin user and host sudo vi /etc/ejabberd/ejabberd.yml Make below changes in the</p>
                                    <a href="blog-single.html" class="know-more">Read more</a>
                                    <div class="social-media-box socialbox">
                                        <ul>
                                            <li><a target="_blank" href="https://www.facebook.com/BriskBrainTechnologies/"><i class="fa fa-facebook"></i></a></li>
                                            <li><a target="_blank" href="https://www.linkedin.com/company/briskbrain/"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a target="_blank" href="https://twitter.com/BriskBrain2"><i class="fa fa-twitter"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/email?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-envelope"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/whatsapp?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-whatsapp"></i></a></li>
                                        </ul>
                                    </div>                                    
                                </li>
                                <li>
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/laravel-orion.png"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid" src="img/blog/laravel-orion.png" alt=""></figure>
                                    </div>
                                    <p class="time">June 24, <span>2021</span></p>
                                    <h5>Building a CRUD system using Laravel 8, Laravel Orion, Angular 11 & JWT</h5>
                                    <div class="box">
                                        <ul class="blog-info">
                                            <li class="comment"><a href="blog-single.html/#commentid">No comments yet</a></li>
                                            <li class="icon-men"><a href="home.html">By admin</a></li>
                                        </ul>
                                    </div>
                                    <p>In this series we’re going to be building a complete CRUD application using Laravel for REST API and Angular on the frontend. In this part, we’ll setup the API part using Laravel Orion. Laravel Orion is a new library which helps us to simplify the API development for our application. We will start with a fresh installation of Laravel.</p>
                                    <a href="blog-single.html" class="know-more">Read more</a>
                                    <div class="social-media-box socialbox">
                                        <ul>
                                            <li><a target="_blank" href="https://www.facebook.com/BriskBrainTechnologies/"><i class="fa fa-facebook"></i></a></li>
                                            <li><a target="_blank" href="https://www.linkedin.com/company/briskbrain/"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a target="_blank" href="https://twitter.com/BriskBrain2"><i class="fa fa-twitter"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/email?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-envelope"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/whatsapp?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-whatsapp"></i></a></li>
                                        </ul>
                                    </div>                                    
                                </li>
                            </ul>
                            <div class="paging-block">
                                <ul>
                                    <li><a href="#" class="prev"><span class="icon-left-arrow"></span></a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#" class="next"><span class="icon-right-arrow"></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <aside class="col-md-4 col-lg-3">
                        <div class="blog-sidebar"> 
                            <div class="cmn-box archive blog-content-common">
                                <h4>Recent Posts</h4>
                                <div class="article-box">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/laravel.png"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/laravel.png" alt=""></figure>
                                    </div>
                                    <p class="blog-title">Top Laravel Best Practices In 2021</p>
                                    <p class="time">July 5, <span>2021</span></p>
                                </div>
                                <div class="article-box">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/laravel-orion.png"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/laravel-orion.png" alt=""></figure>
                                    </div>
                                    <p class="blog-title">Building a CRUD system using Laravel 8, Laravel Orion, Angular 11 & JWT</p>
                                    <p class="time">June 24, <span>2021</span></p>
                                </div>
                                <div class="article-box" style="padding-bottom:10px;">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="img/blog/xampp.jpg"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/xampp.jpg" alt=""></figure>
                                    </div>
                                    <p class="blog-title">How to setup and configure Ejabberd on Ubuntu 16.04 EC2 AWS ?</p>
                                    <p class="time">February 19, <span>2021</span></p>
                                </div>
                            </div>                            
                            <div class="cmn-box archive">
                                <h4>Archieves</h4>
                                <ul>
                                    <li><a href="#">July 05, 2021</a></li>
                                    <li><a href="#">June 24, 2021</a></li>
                                    <li><a href="#">February 19, 2021</a></li>
                                    <li><a href="#">September 16, 2017</a></li>
                                    <li><a href="#">August 15, 2017</a></li>
                                    <li><a href="#">July 12, 2017</a></li>
                                </ul>
                            </div>
                            <div class="cmn-box">
                                <h4>Pages</h4>
                                <ul>
                                    <li><a href="home.html">Home</a></li>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="service.html">Services</a></li>
                                    <li><a href="portfolio.html">Portfolio</a></li>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="contact.html">Contacts</a></li>
                                    <li><a href="request-a-quote.html">Request A Quote</a></li>
                                </ul>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </section>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/blog.blade.php ENDPATH**/ ?>