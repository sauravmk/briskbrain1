	

<?php $__env->startSection('title','Edit Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
	
	<div class="card mt-4">
		<div class="card-header">
			<h4>Edit Users
				<a href="<?php echo e(url('admin/users')); ?>" class="btn btn-danger">Back</a>
			</h4>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/admin/user/edit.blade.php ENDPATH**/ ?>