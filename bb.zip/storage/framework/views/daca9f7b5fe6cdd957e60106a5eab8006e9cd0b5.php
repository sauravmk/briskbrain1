<div class="py-5 bg-dark mt-5 text-white">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h3>Footer</h3>
				<div class="underline"></div>
				<p>This is Footer</p>
			</div>
			<div class="col-md-3">
				<h5>links</h5>
				<div class="underline"></div>
				<div><a href="<?php echo e(url('/')); ?>" class="text-white">Home</a> </div>
				<div><a href="" class="text-white">About Us</a> </div>
				<div><a href="" class="text-white">Countact Us</a> </div>
				<div><a href="" class="text-white">Need Promotion ?</a> </div>
			</div>
			<div class="col-md-3">
				<h5>Follow us</h5>
				<div class="underline"></div>
				<div><a href="https://www.instagram.com/instagram/?hl=en" class="text-white">Instagram</a> </div>
				<div><a href="https://twitter.com/twittersupport" class="text-white">Twitter</a> </div>
				<div><a href="https://www.facebook.com/facebook/" class="text-white">Facebook</a> </div>
				<div><a href="https://business.linkedin.com/marketing-solutions/linkedin-pages" class="text-white">Linked in</a> </div>
			</div>
		</div>
	</div>
</div>
<div class="py-2 bg-gray">
	<div class="container text-center">
		<p class="mb-0">
				
		</p>
	</div>
</div><?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/layouts/inc/admin-footer.blade.php ENDPATH**/ ?>