<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta name="author" content="Funda of Web IT">
   

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- style -->
    <link rel="stylesheet"  href="<?php echo e(asset('assets/css/styles.css')); ?>">
    <link rel="stylesheet"  href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet"  href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet"  href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">

   
</head>
<body>

    <div id="app">

       <?php echo $__env->make('layouts.inc.frontend-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <?php echo $__env->make('layouts.inc.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
     <!-- Scripts -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>

    
</body>
</html>
<?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/layouts/app.blade.php ENDPATH**/ ?>