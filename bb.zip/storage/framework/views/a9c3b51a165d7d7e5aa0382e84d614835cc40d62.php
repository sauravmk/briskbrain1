	

<?php $__env->startSection('title','Eidt Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
	
	<div class="card mt-4">
		
		<div class="card-header">
			<h4>Edit Post
				<a href="<?php echo e(url('admin/posts')); ?>" class="btn btn-danger float-end">Back</a>
			</h4>
		</div>
		<div class="card-body">
				<?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"> <?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
			<form method="POST" action="<?php echo e(url('admin/update-post/'.$post->id)); ?>">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<div class="mb-3">
					<label for="">Category</label>
					<select name="category_id" required class="form-control">
						<option>--Select Category--</option>
						<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($catitem->id); ?>" <?php echo e($post -> category_id == $catitem->id ? 'selected':''); ?> >
								<?php echo e($catitem->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="mb-3">
					<label for="">Post Name</label>
					<input type="tex" name="name" value="<?php echo e($post->name); ?>" class="form-control">
				</div>
				<div class="mb-3">
					<label for="">Slug</label>
					<input type="tex" name="slug" value="<?php echo e($post->slug); ?>"class="form-control">
				</div>
				<div class="mb-3">
					<textarea name="description" id="mySummernote" class="form-control"><?php echo $post->description; ?></textarea>
				</div>
				<div class="mb-3">
					<label for="">YouTube IframLink</label>
					<input type="text" name="yt_iframe" value="<?php echo e($post->yt_iframe); ?>"class="form-control">
				</div>
				<h4>SEO Tag</h4>
				 <div class="mb-3">
                    <label for="">Meta Title</label>
                    <input type="text" name="meta_title" value="<?php echo e($post->meta_title); ?>"class="form-control">
                </div>
                <div class="mb-3">
                    <label for="">Meta Description</label>
                    <textarea  name="meta_description" rows="3" class="form-control" ><?php echo $post->meta_description; ?></textarea>
                </div>
                 <div class="mb-3">
                    <label for="">Meta Keywords</label>
                    <textarea  name="meta_keyword" rows="3" class="form-control" value=""><?php echo $post->meta_keyword; ?></textarea>
                </div>
                <h4>Status</h4>
                <div class="row">
                	<div class="col-md-4">
                		<div class="mb-3">
                			<label for="">Status</label>
                			<input type="checkbox" name="status" <?php echo e($post->status == '1' ? 'checked':''); ?>>                			
                		</div>                		
                	</div>
                </div>
                <div class="col-md-8">
                	<div class="mb-3">
                		<button type="submit" class="btn btn-primary float-end">Update Post</button>                		
                	</div>                	
                </div>
			</form>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/saurav/laravel/myproject/resources/views/admin/post/edit.blade.php ENDPATH**/ ?>