@extends('layouts.app')
@section('content')
        <section class="banner-section blog-banner">
            <div class="container">
                <div class="contents">
                    <h1>Blog</h1>
                    <p>Do you want to discuss your project with us? Well, give us a call, send us an email or fill out below form.</p>
                </div>
            </div>
        </section>
        <section class="blog-section pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-lg-9">
                        <div class="blog-content">
                            <ul class="blog-content-common">
                                <li class="pb-2">
                                    <figure class="blog-pic"><img class="img-fluid" src="img/blog/laravel.png" alt=""></figure>
                                    <p class="time">July 5, <span>2021</span></p>
                                    <h5>TOP LARAVEL BEST PRACTICES IN 2021</h5>
                                    <div class="box">
                                        <ul class="blog-info">
                                            <li class="comment"><a href="javascript:void(0)">No comments yet</a></li>
                                            <li class="icon-men"><a href="home.html">By admin</a></li>
                                        </ul>
                                    </div>
                                    <p>You can see the use of smartphones is increasing with every second of the time. It’s logical that if the use of smartphones increases, then the use of applications and websites is also going to increase. So, it is always beneficial to be updated with advanced development frameworks. Recently many new languages have been introduced in the market and the best thing you can do for your business is to adapt to the best one. Yes, If you are having doubts, let me clarify that the best framework is Laravel.</p>
                                    <p>In 2011, Taylor Otwell Introduced Laravel Framework to give the development work little calmness. One of the great things about Laravel is, it not only blesses developers by making their work smooth and fast but also offers some outstanding features and tools to developers.</p>
                                    <p>Day by day Laravel is advancing and recently Laravel 8 was released. Today, we are going to discuss some best practices you should follow for Laravel development. You can also Hire Laravel developer from Laravel development Company and get done with the Laravel development work with all the possible best practices.</p>
                                    <h2>Let’s jump into the interesting list of Laravel best practices.</h2>
                                    <h3 class="blog-maintitle">1. Use Advances Version</h3>
                                    <p>When we use an advanced version, it will always lead us towards the security and quality performance solution for our web projects. It’s preferable to work with advanced Laravel versions for your web application development project. Recently, Laravel 8 was released, So it is advisable to work with Laravel 8 for web development solutions.</p>
                                    <h3 class="blog-maintitle">2. Never Execute Queries In Blade Templates</h3>
                                    <div class="blog-quote">
                                        <p>Not to Do (for 100 posts, 101 DB queries will be executed):</p>
                                        <p>@foreach (Post::all() as $post)</p>
                                        <p>{{ $post-&gt;category-&gt;name }}</p>
                                        <p>@endforeach</p>
                                        <p>To Do (for 100 posts, 2 DB queries will be executed):</p>
                                        <p>$posts = Post::with(‘category’)-&gt;get();</p>
                                        <p>…</p>
                                        <p>@foreach ($posts as $post)</p>
                                        <p>{{ $post-&gt;category-&gt;name }}</p>
                                        <p>@endforeach</p>
                                    </div>
                                    <h3 class="blog-maintitle">3. Use Eloquent Orm</h3>
                                    <p>Laravel has some amazing features but Eloquent ORM is the most powerful, this feature is used to extract the data which will be shown to the users by a single query. If you are working on a web app development project based on Laravel, then the use of Eloquent Orm will be the best practice for you.</p>
                                    <div class="blog-quote">
                                        <p>Not to Do:</p>
                                        <p>SELECT *</p>
                                        <p>FROM `posts`</p>
                                        <p>WHERE EXISTS (SELECT *</p>
                                        <p>FROM `users`</p>
                                        <p>WHERE `posts`.`user_id` = `users`.`id`</p>
                                        <p>AND EXISTS (SELECT *</p>
                                        <p>FROM `profiles`</p>
                                        <p>WHERE `profiles`.`user_id` = `users`.`id`)</p>
                                        <p>AND `users`.`deleted_at` IS NULL)</p>
                                        <p>AND `active` = ‘1’</p>
                                        <p>ORDER BY `created_at` DESC</p>
                                        <p>Should Use:</p>
                                        <p>Post::has(‘user.profile’)-&gt;active()-&gt;latest()-&gt;get();</p>
                                    </div>
                                    <h3 class="blog-maintitle">4. Condensing the use of plugins</h3>
                                    <p>Lots of plugins are available to make the development process more smooth and easy. The use of such good plugins adds valuable functionalities in the development. but at the same time, it is important to use it in limited numbers. If you use it every way, it will affect the performance of your web application.</p>
                                    <h3 class="blog-maintitle">5. Considering the standards</h3>
                                    <p>If you want to make your web solutions authentic and genuine in nature, you must follow the standards. When any framework or language was introduced. It comes with basic standards that must be followed for the best performance and outputs. Developers must follow this standard to make the development tasks more smooth and easy. Like PSR — 0 to 4 are coding standards that must be followed.</p>
                                    <h3 class="blog-maintitle">6. Validation</h3>
                                    <p>Move validation from controllers to Request classes.</p>
                                    <div class="blog-quote">
                                        <p>Not To Use:</p>
                                        <p>public function store(Request $request)</p>
                                        <p>{</p>
                                        <p>$request-&gt;validate([</p>
                                        <p>‘title’ =&gt; ‘required|unique:articles|max:255’,</p>
                                        <p>‘body’ =&gt; ‘required’,</p>
                                        <p>‘publish_at’ =&gt; ‘nullable|date’,</p>
                                        <p>]);</p>
                                        <p>}</p>
                                        <p>Should Use:</p>
                                        <p>public function store(ArticleRequest $request)</p>
                                        <p>{</p>
                                        <p>}</p>
                                        <p>class ArticleRequest extends Request</p>
                                        <p>{</p>
                                        <p>public function rules()</p>
                                        <p>{</p>
                                        <p>return [</p>
                                        <p>‘title’ =&gt; ‘required|unique:articles|max:255’,</p>
                                        <p>‘body’ =&gt; ‘required’,</p>
                                        <p>‘publish_at’ =&gt; ‘nullable|date’,</p>
                                        <p>];</p>
                                        <p>}</p>
                                        <p>}</p>
                                    </div>
                                    <h3 class="blog-maintitle">7. Inducing a JIT Compiler Code</h3>
                                    <p>At some time, developers want to understand the PHP codes and for that, they make generous use of compilers. But code compilers will affect the web app performance negatively. But if you don’t want to sacrifice your web app performance, then you can use HHVM, the strongest JIT compiler. With JIT, you can compile the PHP code more quickly and smoothly, and also JIT helps you to accelerate your performance.</p>
                                    <h3 class="blog-maintitle">Over To You</h3>
                                    <p>When you are required to develop a smooth and commendable web solution for Laravel, these mentioned points are the best practices that must be followed. With Laravel development, you can get credit as well as authentic development in nature. But best practices are not enough, you need knowledgeable and experienced Laravel developers for your project. If you want to implement these best practices to your web solution, Contact the Best <a href="javascript:void(0)"><strong>Laravel Development Company</strong></a> and make your work authentic and genuine in nature.</p>
                                    <div class="social-media-box socialbox">
                                        <ul>
                                            <li><a target="_blank" href="https://www.facebook.com/BriskBrainTechnologies/"><i class="fa fa-facebook"></i></a></li>
                                            <li><a target="_blank" href="https://www.linkedin.com/company/briskbrain/"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a target="_blank" href="https://twitter.com/BriskBrain2"><i class="fa fa-twitter"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/email?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-envelope"></i></a></li>
                                            <li><a target="_blank" href="https://www.addtoany.com/add_to/whatsapp?linkurl=https%3A%2F%2Fwww.briskbraintech.com%2Fbuilding-a-crud-system-using-laravel-8-laravel-orion-angular-11-jwt%2F&linkname=Building%20a%20CRUD%20system%20using%20Laravel%208%2C%20Laravel%20Orion%2C%20Angular%2011%20%26%20JWT&linknote="><i class="fa fa-whatsapp"></i></a></li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <aside class="col-md-4 col-lg-3">
                        <div class="blog-sidebar"> 
                            <div class="cmn-box archive blog-content-common">
                                <h4>Recent Posts</h4>
                                <div class="article-box">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="javascript:void(0)"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/laravel.png" alt=""></figure>
                                    </div>
                                    <p class="blog-title">Top Laravel Best Practices In 2021</p>
                                    <p class="time">July 5, <span>2021</span></p>
                                </div>
                                <div class="article-box">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="javascript:void(0)"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/laravel-orion.png" alt=""></figure>
                                    </div>
                                    <p class="blog-title">Building a CRUD system using Laravel 8, Laravel Orion, Angular 11 & JWT</p>
                                    <p class="time">June 24, <span>2021</span></p>
                                </div>
                                <div class="article-box" style="padding-bottom:10px;">
                                    <div class="image-blog">
                                        <div class="overlay">
                                            <a class="galleryItem" href="javascript:void(0)"><span class="icon-expand"></span></a>
                                        </div>
                                        <figure class="blog-pic"><img class="img-fluid img-blogimage" src="img/blog/xampp.jpg" alt=""></figure>
                                    </div>
                                    <p class="blog-title">How to setup and configure Ejabberd on Ubuntu 16.04 EC2 AWS ?</p>
                                    <p class="time">February 19, <span>2021</span></p>
                                </div>
                            </div>                            
                            <div class="cmn-box archive">
                                <h4>Archieves</h4>
                                <ul>
                                    <li><a href="#">July 05, 2021</a></li>
                                    <li><a href="#">June 24, 2021</a></li>
                                    <li><a href="#">February 19, 2021</a></li>
                                    <li><a href="#">September 16, 2017</a></li>
                                    <li><a href="#">August 15, 2017</a></li>
                                    <li><a href="#">July 12, 2017</a></li>
                                </ul>
                            </div>
                            <div class="cmn-box">
                                <h4>Pages</h4>
                                <ul>
                                    <li><a href="home.html">Home</a></li>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="service.html">Services</a></li>
                                    <li><a href="portfolio.html">Portfolio</a></li>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="contact.html">Contacts</a></li>
                                    <li><a href="request-a-quote.html">Request A Quote</a></li>
                                </ul>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </section>
        <section class="comment-section pb-5" id="commentid">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <form name="contact-form">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="blog-maintitle">Leave A Comment</h3>
                                    <div class="form-group">
                                        <label>Comment</label>
                                        <textarea class="form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input name="contact" class="form-control" placeholder="" type="text">
                                    </div>
                                    <div class="form-group required">
                                        <label>Email</label>
                                        <input name="contact" class="form-control" placeholder="" type="text">
                                    </div>
                                    <div class="form-group">
                                        <label>Website</label>
                                        <input name="contact" class="form-control" placeholder="" type="text">
                                    </div>
                                    <div class="form-group">
                                        <button class="btn submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6"></div>
                </div>
            </div>
        </section>
        @endsection