<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controller\HomeController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\frontend\FrontendController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/',[FrontendController::class,'index']);
Route::get('/about',[App\Http\Controllers\HomeController::class,'about'])->name('about');
Route::get('/portfolio',[App\Http\Controllers\HomeController::class,'portfolio'])->name('portfolio');
Route::get('/blog',[App\Http\Controllers\HomeController::class,'blog'])->name('blog');
Route::get('/contact',[App\Http\Controllers\HomeController::class,'contact'])->name('contact');
Route::get('/service',[App\Http\Controllers\HomeController::class,'service'])->name('service');

Route::prefix('admin')->middleware(['auth','isAdmin'])->group(function()
{
    Route::get('/dashboard',[DashboardController::class,'index']);

    Route::get('/category',[CategoryController::class,'index']);
    Route::get('add-category',[CategoryController::class,'create']);
    Route::post('add-category',[CategoryController::class,'store']);
    Route::get('edit-category/{category_id}',[CategoryController::class,'edit']);
    Route::put('update-category/{category_id}',[CategoryController::class,'update']);
    Route::get('delete-category/{category_id}',[CategoryController::class,'delete']);
    //Route::post('delete-category',[CategoryController::class,'delete']);

    //For Posts
    Route::get('posts',[PostController::class,'index']);
    Route::get('add-post',[PostController::class,'create']);
    Route::post('add-post',[PostController::class,'store']);
    Route::get('post/{post_id}',[PostController::class,'edit']);
    Route::put('update-post/{post_id}',[PostController::class,'update']);
    Route::get('delete-post/{post_id}',[PostController::class,'delete']);

    //For Users
    Route::get('users/{id}',[UserController::class,'edit']);
    Route::get('users',[UserController::class,'index']);
    
    
});